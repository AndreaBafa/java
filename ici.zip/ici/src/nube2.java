/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Andrea
 */
public class nube2 
{
    public static void main(String[] args)
    {
        nube n_1=new nube(7,11);
        nube n_2=new nube(8,10);
        
        if(n_1.rain() > n_2.rain())
        {
            System.out.println("La nube 1 es mayor "+n_1.rain());
        }
        else 
        {
            System.out.println("la nube 2 es mayor "+ n_2.rain());
        }
    }
}
