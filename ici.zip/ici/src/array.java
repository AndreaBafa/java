
import java.io.OutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Andrea
 */
public class array {
    public static void main (String args[])
    {
        //para que jale se pone el catch 
         int arr[]={11,21,3,40,5};
         try
         {
             OutputStream os= new FileOutputStream("texto.txt");
             for(int x=0;x<arr.length;x++)
             {
                 os.write(arr[x]);
             }os.close();
             
             InputStream file=new FileInputStream("texto.txt");
             int size =file.available();
             
             for(int i=0;i<size;i++)
             {
                 System.out.println(file.read()+" ");
             }file.close();
             
         } catch (IOException e) {
           // Logger.getLogger(array.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("EXCEPTION");
        }
    }
     
}
