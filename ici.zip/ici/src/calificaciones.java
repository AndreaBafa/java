/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Andrea
 */
//funcion
import java.util.Random;
public class calificaciones 
{
    public static void main(String[] args)
    {
        Random rand=new Random();
        int a,tot;
        int reprobados=0;
        int n7=0,n8=0,n9=0,n10=0;
        a=rand.nextInt(10); //asiganar los valores entre cero y 10
        
        int []cal;
        cal=new int[1000];
        
        for(int i=0;i<1000;i++)
        {
              cal[i]=rand.nextInt(10);
            switch(cal[i])
            {
                case 0:
                reprobados=reprobados+1;
                break;
                case 1:
                                reprobados=reprobados+1; //contador 
                break;
                case 2:
                                reprobados=reprobados+1;
                break;
                case 3:
                               reprobados=reprobados+1;
                break;
                 case 4:
                               reprobados=reprobados+1;
                break;
                case 5:
                               reprobados=reprobados+1;
                break;
                case 6:
                                reprobados=reprobados+1;
                break;
                case 7:
                n7=n7+1;
                break;
                case 8:
                n8=n8+1;
                break;
                case 9:
                n9=n9+1;
                break;
                case 10:
                n10=n10+1;
                break;
            }
        }
        
        //impresion de alumnos 
        System.out.println("Alumnos con calif  reprobatoria: "+reprobados);
        System.out.println("Alumnos con calif 7: "+n7);
        System.out.println("Alumnos con calif 8: "+n8);
        System.out.println("Alumnos con calif 9: "+n9 );
        
        tot=(reprobados+n7+n8+n9+n10);
        System.out.println("Total de alumnos: "+tot);
    }
}
