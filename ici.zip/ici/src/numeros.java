/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Andrea
 */
public class numeros
{
 public static void main(String [] args)
 {
     int a1=12, a2=7, a3=11, a4=20, a5=12, a6=14;
     int a= (Math.max (a1,a2));
     int b= (Math.max(a3,a4)); //la función solo puede conparar dos 
     int c= (Math.max(a5,a6));
     int andrea=(Math.max(a,b));
     int yeyo=(Math.max(b,c));
     System.out.println("el número mayor "+Math.max(andrea, yeyo)); 
 }
}
