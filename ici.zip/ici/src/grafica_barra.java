import javax.swing.JFrame;  
    import javax.swing.SwingUtilities;  
      
    import org.jfree.chart.ChartFactory;  
    import org.jfree.chart.ChartPanel;  
    import org.jfree.chart.JFreeChart;  
    import org.jfree.chart.plot.PlotOrientation;  
    import org.jfree.data.category.CategoryDataset;  
    import org.jfree.data.category.DefaultCategoryDataset;  
      

public class grafica_barra extends JFrame {
     public grafica_barra(String appTitle) {  
        super(appTitle);  
      
        // Create Dataset  
        CategoryDataset dataset = createDataset();  
          
        //Create chart  
        JFreeChart chart=ChartFactory.createBarChart(  
            "Poblacion rural y urbana", //Chart Title  
            "Edad", // Category axis  
            "Poblacion", // Value axis  
            dataset,  
            PlotOrientation.VERTICAL,  
            true,true,false  
           );  
      
        ChartPanel panel=new ChartPanel(chart);  
        setContentPane(panel);  
      }  
      
      private CategoryDataset createDataset() {  
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();  
      
        // Population in 2005  
        dataset.addValue(11.7, "H Rural", "50-54");  
        dataset.addValue(8.1, "M Rural", "50-54");  
        dataset.addValue(15.4, "H Urbano", "50-54");  
        dataset.addValue(8.4, "M Urbana", "50-54");  
      
        // Population in 2010  
        dataset.addValue(18.1, "H Rural", "55-59");  
        dataset.addValue(11.7, "M Rural", "55-59");  
        dataset.addValue(24.4, "H Urbano", "55-59");  
        dataset.addValue(13.6, "M Urbana", "55-59");  
       
      
        // Population in 2015  
        dataset.addValue(26.7, "H Rural", "60-64");  
        dataset.addValue(20.3, "M Rural", "60-64");  
        dataset.addValue(37.0, "H Urbano", "60-64");  
        dataset.addValue(19.3, "M Urbana", "60-64");  
        
        dataset.addValue(41, "H Rural", "65-69");  
        dataset.addValue(31, "M Rural", "65-69");  
        dataset.addValue(54.6, "H Urbano", "65-69");  
        dataset.addValue(35.1, "M Urbana", "65-69");
       
        dataset.addValue(66, "H Rural", "70-74");  
        dataset.addValue(54.3, "M Rural", "70-74");  
        dataset.addValue(71, "H Urbano", "70-74");  
        dataset.addValue(50, "M Urbana", "70-74");  
        
      
        return dataset;  
      }  
      
      public static void main(String[] args) throws Exception {  
        SwingUtilities.invokeAndWait(()->{  
          grafica_barra example=new grafica_barra("Bar Chart Window");  
          example.setSize(800, 400);  
          example.setLocationRelativeTo(null);  
          example.setDefaultCloseOperation(EXIT_ON_CLOSE);  
          example.setVisible(true);  
        });  
      }  
 
}