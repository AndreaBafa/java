import java.awt.Color;  
    import javax.swing.JFrame;  
    import javax.swing.SwingUtilities;  
    import javax.swing.WindowConstants;  
    import org.jfree.chart.ChartFactory;  
    import org.jfree.chart.ChartPanel;  
    import org.jfree.chart.JFreeChart;  
    import org.jfree.chart.plot.XYPlot;  
    import org.jfree.data.xy.XYDataset;  
    import org.jfree.data.xy.XYSeries;  
    import org.jfree.data.xy.XYSeriesCollection;  
      
public class xy_plot extends JFrame {
     public xy_plot(String title) {  
        super(title);  
      
        // Create dataset  
        XYDataset dataset = createDataset();  
      
        // Create chart  
        JFreeChart chart = ChartFactory.createScatterPlot(  
            "Gráfica dado los valores n y m ",   
            "x", "Y", dataset);  
      
          
        //Changes background color  
        XYPlot plot = (XYPlot)chart.getPlot();  
        plot.setBackgroundPaint(new Color(255,228,196));  
          
         
        // Create Panel  
        ChartPanel panel = new ChartPanel(chart);  
        setContentPane(panel);  
      }  
      
      private XYDataset createDataset() {  
        XYSeriesCollection dataset = new XYSeriesCollection();  
      
        //Boys (Age,weight) series  
        XYSeries series1 = new XYSeries("valores n");  
        series1.add(1, 0.084);  
        series1.add(2, 0.22);  
        series1.add(3, 0.43);  
        series1.add(4, 0.55);  
        series1.add(5, 0.59);  
        series1.add(6, 0.84);  
        series1.add(7, 0.22);  
        series1.add(8, 0.43);  
        series1.add(9, 0.55);  
        series1.add(10, 0.59);  
      
        dataset.addSeries(series1);  
          
       //Girls (Age,weight) series  
        XYSeries series2 = new XYSeries("valores m");  
        series2.add(1, 0.45);  
        series2.add(2, 0.64);  
        series2.add(3, 0.15);  
        series2.add(4, 0.64);  
        series2.add(5, 0.38);  
        series2.add(6, 0.45);  
        series2.add(7, 0.64);  
        series2.add(8, 0.15);  
        series2.add(9, 0.64);  
        series2.add(10, 0.38);  
         dataset.addSeries(series2); 
        XYSeries series3 = new XYSeries("valores y");  
        series3.add(1, 0.43);  
        series3.add(2, 0.64);  
        series3.add(3, 0.15);  
        series3.add(4, 0.64);  
        series3.add(5, 0.31);  
        series3.add(6, 0.42);  
        series3.add(7, 0.63);  
        series3.add(8, 0.18);  
        series3.add(9, 0.69);  
        series3.add(10, 0.39);  
       dataset.addSeries(series3); 
        
      
        return dataset;  
      }  
            public static void main(String[] args) {  
        SwingUtilities.invokeLater(() -> {  
          xy_plot example = new xy_plot("x-y");  
          example.setSize(800, 400);  
          example.setLocationRelativeTo(null);  
          example.setDefaultCloseOperation(EXIT_ON_CLOSE);  
          example.setVisible(true);  
        });  
      }  

      
}
