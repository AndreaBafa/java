/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto2;

import java.awt.HeadlessException;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;

/**
 *
 * @author Andrea
 */
public class proyecto2 extends JFrame
{
    ArrayList <JPanel> panel=new ArrayList<JPanel>();
    ArrayList <JLabel> label=new ArrayList<JLabel>();
    ArrayList <JRadioButton> listarb=new ArrayList<JRadioButton>();
    JPanel contenedor=new JPanel();
    JButton b1;
    int num=4;
    
    public proyecto2(String title) throws HeadlessException, InterruptedException
    {
        super(title);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setBounds(300,300,500,500);
        this.setLocationRelativeTo(null);
        this.getContentPane().add(contenedor);
        iniciaAreaTexto();
    }

    proyecto2() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void iniciaAreaTexto() {
        JTextArea areatexto=new JTextArea(); 
        //areatexto.setBounds(100,100,300,150);
        //ponemos el area en el contenedor
        areatexto.setText("hola hola ");
        areatexto.setEnabled(true);
        areatexto.setEditable(true);
        JScrollPane scroll=new JScrollPane(areatexto);
        scroll.setBounds(100,100,300,150);
        this.contenedor.add(areatexto);
        System.out.println(areatexto.getText());
    }

    private JScrollPane JScrollPane(JTextArea areatexto) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
