/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto2;

/**
 *
 * @author Andrea
 */
public class ventana 
{
    public static void main(String[] args)
{
  proyecto2 p=new proyecto2();
  p.setVisible(true);
}
}
