/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Andrea
 */
public class nube {
    int weight;
    int width;
    
    //constructor 
    nube(int w, int wi)
    {
        weight=w;
        width=wi;
    }
     int rain()
    {
        return weight*width;
    }
}
