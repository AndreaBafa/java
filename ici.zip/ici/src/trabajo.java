/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Andrea
 */
public class trabajo 
{
    
public static void main(String[] args)
    {
      int [] arr; //lo declaramos
        arr=new int [10]; //le damo espacio al arreglo
        int i;
        
        //llenarlo
        arr[0]= 7; 
        arr[1]=3;
        arr[2]=2;
        arr[3]=5;
        arr[4]=14;
        arr[5]=17;
        arr[6]=9;
        arr[7]=21;
        arr[8]=32;
        arr[9]=67;
        
        for(i=0;i<10;i++)
        {
            System.out.println("imprimiendo valor de la posición ["+ i +"]"+"="+arr[i]);
        }
    
}}
