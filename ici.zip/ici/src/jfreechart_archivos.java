/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Andrea
 */
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class jfreechart_archivos extends JFrame implements ActionListener {

        JPanel panel1;
        JTextArea text1;
        JButton but1;
        
        jfreechart_archivos()
        {
         panel1 = new JPanel();
         text1=new JTextArea(15,15);
         but1=new JButton("leer");
         but1.addActionListener(this);
         panel1.add(text1);
         panel1.add(but1);
         add(panel1);

      setLayout(new GridLayout(1, 1));  
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setSize(550,350);

        }

    @Override
    public void actionPerformed(ActionEvent e) {
               
    try
    {
        JFileChooser open = new JFileChooser();
        int option = open.showOpenDialog(this);
        File f1 = new File(open.getSelectedFile().getPath());
        try (FileReader fr = new FileReader(f1)) {
            BufferedReader br = new BufferedReader(fr);
            String s;
            while((s=br.readLine())!=null)
            {
                text1.append(s + "\n");
            }
        }
            }
            catch(HeadlessException | IOException ae)
                {
                System.out.println(ae);
               }    

       
    }
    
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new jfreechart_archivos().setVisible(true);
            }
        });
     }

    
}
